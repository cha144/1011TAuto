/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// Lm                   motor         2               
// Lb                   motor         3               
// Lf                   motor         1               
// Rf                   motor         10              
// Rm                   motor         9               
// Rb                   motor         8               
// R8                   motor         18              
// L8                   motor         4               
// IMU1                 inertial      7               
// LeftWing             digital_out   B               
// RightWing            digital_out   H               
// Arm                  digital_out   A               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
#include <cmath>

using namespace vex;

// A global instance of competition
competition Competition;

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
}

double kP = 0.045;
//double kI = 0.00001;
double kD = 0.04;



double turnkP = -0.02;
//double turnkI = 0.0;
double turnkD = -0.001;


int desiredValue;

int desiredTurnValue;


int error; //sensor - desired : position
int prevError; // position 20 milleseconds ago
int derivative; // error - prevError : speed
int totalError; //totalError = totalError + error


int turnerror; //sensor - desired : position
int turnprevError; // position 20 milleseconds ago
int turnderivative; // error - prevError : speed
int turntotalError; //totalError = totalError + error


bool resetDriveSensors = false;


bool enablePID = true;


///////////////////////////////////////////////////////////////////////////////////////////////////////////////

int drivePID(){

  while(enablePID){

    if (resetDriveSensors){
      resetDriveSensors = false;
      Lf.setPosition(0, degrees);
      Lb.setPosition(0, degrees);
      Lm.setPosition(0, degrees);
      L8.setPosition(0, degrees);
      Rf.setPosition(0, degrees);
      Rm.setPosition(0, degrees);
      Rb.setPosition(0, degrees);
      R8.setPosition(0, degrees);

    }

    int LMAPosition = Lf.position(degrees);
    int LMBPosition = Lb.position(degrees);
    int LMCPosition = Lm.position(degrees);
    int LMDPosition = L8.position(degrees);
    int RMAPosition = Rf.position(degrees);
    int RMBPosition = Rm.position(degrees);
    int RMCPosition = Rb.position(degrees);
    int RMDPosition = R8.position(degrees);
    
    int LeftGroupPosition = (LMAPosition  + LMBPosition + LMCPosition + LMDPosition)/4;
    int RightGroupPosition= (RMAPosition + RMBPosition + RMCPosition + RMDPosition)/4;
   
   
   //////////////////////////////////////////////////////////////////////////////////////
    int averagePosition = (LeftGroupPosition + RightGroupPosition)/2;

    error = desiredValue - averagePosition;

    derivative = error - prevError;

    totalError += error;
    double LateralmotorPower = error * kP + derivative * kD;


 ////////////////////////////////////////////////////////////////////////////////////////////////

    int turnDifference = LeftGroupPosition - RightGroupPosition ;
    turnerror = desiredTurnValue - turnDifference;

    turnderivative = turnerror - turnprevError;

    turntotalError += turnerror;
    double turnmotorPower = turnerror * turnkP + turnderivative * turnkD;

////////////////////////////////////////////////////////////////////////////////////////////////////

    // Motor5.spin(forward, LateralmotorPower + turnmotorPower, voltageUnits::volt);
    //Motor6.spin(forward, LateralmotorPower - turnmotorPower, voltageUnits::volt);

    Lf.spin(forward, (LateralmotorPower - turnmotorPower)*0.6,voltageUnits::volt);

    Lb.spin(forward, (LateralmotorPower - turnmotorPower)*0.6, voltageUnits::volt);

    Lm.spin(forward, (LateralmotorPower - turnmotorPower)*0.6,voltageUnits::volt);

    L8.spin(forward, (LateralmotorPower - turnmotorPower)*0.6,voltageUnits::volt);

    Rf.spin(forward, (LateralmotorPower + turnmotorPower)*0.6, voltageUnits::volt);

    Rm.spin(forward, (LateralmotorPower + turnmotorPower)*0.6, voltageUnits::volt);

    Rb.spin(forward, (LateralmotorPower + turnmotorPower)*0.6, voltageUnits::volt);

    R8.spin(forward, (LateralmotorPower + turnmotorPower)*0.6, voltageUnits::volt);
    
    prevError = error;
    turnprevError = turnerror;
    

    vex::task::sleep(20);

  }

  return 1;

}
void forwardMotor() {
  int run = 1;
  while(run == 1) {
    Lf.spin(forward, 100, pct);

    Lb.spin(forward, 100, pct);

    Lm.spin(forward, 100, pct);

    L8.spin(forward, 100, pct);

    Rf.spin(forward, 100, pct);

    Rm.spin(forward, 100, pct);

    Rb.spin(forward, 100, pct);

    R8.spin(forward, 100, pct);

    wait(0.4, sec);

    Lf.stop();
    Lb.stop();
    Lm.stop();
    L8.stop();
    Rf.stop();
    Rm.stop();
    Rb.stop();
    R8.stop();
    run = 0;
  }
}

void autonomous(void) {
  //for comments, the code above it is what it does
  resetDriveSensors = true;
  enablePID = true;

  RightWing.set(true);
  LeftWing.set(true);

  vex::task TEST(drivePID);

  Arm.set(true);
  wait(0.01, sec);
  RightWing.set(false);
  LeftWing.set(false);

  resetDriveSensors = true;
  desiredValue = 1930;
  wait(0.75, sec);

  Arm.set(false);
  wait(0.3, sec);

  desiredTurnValue = 640;
  wait(0.3,sec);

  Arm.set(true);
  LeftWing.set(true);
  RightWing.set(true);
  wait(0.5, sec);
  
  resetDriveSensors = true;
  desiredValue = 870;
  desiredTurnValue = 0;
  

  wait(0.8, sec);

  RightWing.set(false);
  LeftWing.set(false);

  resetDriveSensors = true;
  desiredValue = -350;
  desiredTurnValue = 0;

  wait(0.9, sec);
  resetDriveSensors = true;
  desiredValue = 0;
  desiredTurnValue = 950;

  wait(0.8, sec);
  resetDriveSensors = true;
  desiredValue = 1790;
  desiredTurnValue = 0;

  wait(0.8, sec);

  Arm.set(false);
  resetDriveSensors = true;
  desiredValue = 0;
  desiredTurnValue = -690;

  wait(0.8, sec);

  resetDriveSensors = true;
  desiredValue = -570;
  desiredTurnValue = 0;

  wait(0.8, sec);

  resetDriveSensors = true;
  desiredValue = 0;
  desiredTurnValue = 300;

  wait(0.8, sec);

  resetDriveSensors = true;
  desiredValue = -600;
  desiredTurnValue = 0;

   wait(0.8, sec);

  resetDriveSensors = true;
  desiredValue = 800;
  desiredTurnValue = -800;
  
}

   bool wingsOn = false;
    bool armOn = false;
    bool cataOn = false;
    bool blockaOn = false;

void togglewings() {
  wingsOn = !wingsOn;
}

void togglearm() {
  armOn = !armOn;
}

void togglecata() {
  cataOn = !cataOn;
}

void toggleblocka() {
  blockaOn = !blockaOn;
}

void usercontrol(void) {

  enablePID = false;

  //Driver Control
  double turnImportance = 0.05;
  
  Rf.setStopping(brake);
  Rm.setStopping(brake);
  Rb.setStopping(brake);
  R8.setStopping(brake);
  Lf.setStopping(brake);
  Lm.setStopping(brake);
  Lb.setStopping(brake);
  L8.setStopping(brake);

  Controller1.ButtonL2.pressed(togglewings);
  Controller1.ButtonR1.pressed(togglearm);
  Controller1.ButtonUp.pressed(togglecata);
  Controller1.ButtonX.pressed(toggleblocka);
 
  while (1) {
    
    ///////////////////////////////////////////
    //Driver Control
    ////////////////////////////////////////////////////////////////////                                                                                                                                                                                                            /
    
    double turnVal = Controller1.Axis1.position(percent);
    double forwardVal = Controller1.Axis3.position(percent);

    double turnVolts = turnVal * 0.12;
    double forwardVolts = forwardVal * 0.12 * (1 - (std::abs(turnVolts)/12.0) * turnImportance);

    double leftVolts = (forwardVolts + turnVolts) ;
    double rightVolts = (forwardVolts - turnVolts) ; //* 0.825; //might need to adjust more

    Lf.spin(forward, leftVolts, volt);
    Lm.spin(forward, leftVolts, volt);
    Lb.spin(forward, leftVolts, volt);
    L8.spin(forward, leftVolts, volt);
    Rf.spin(forward, rightVolts, volt);
    Rm.spin(forward, rightVolts, volt);
    Rb.spin(forward, rightVolts, volt);
    R8.spin(forward, rightVolts, volt);
    
  
  if(wingsOn)
     {
       LeftWing.set(true);
       RightWing.set(true);
       Brain.Screen.print(1);
     }
  else {
      LeftWing.set(false);
      RightWing.set(false);
      Brain.Screen.print(0);
  }

  if(blockaOn) {
    Blocka.set(true);
  }
  else {
    Blocka.set(false);
  }
  
  if(armOn) {
    Arm.set(true);
  }
  else {
    Arm.set(false);
  }
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
