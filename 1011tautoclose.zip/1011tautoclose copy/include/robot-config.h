using namespace vex;

extern brain Brain;

// VEXcode devices
extern controller Controller1;
extern motor Lm;
extern motor Lb;
extern motor Lf;
extern motor Rf;
extern motor Rm;
extern motor Rb;
extern motor R8;
extern motor L8;
extern inertial IMU1;
extern digital_out LeftWing;
extern digital_out RightWing;
extern digital_out Arm;
extern digital_out Blocka;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void  vexcodeInit( void );